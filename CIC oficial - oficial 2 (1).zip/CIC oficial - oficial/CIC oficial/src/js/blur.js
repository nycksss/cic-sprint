

const ncnpje = document.querySelector('#ncnpje')
const ncnpjce = document.querySelector('#ncnpjce')
const cnpj = document.querySelector('#cnpj')

console.log(ncnpjce);

ncnpje.addEventListener('click',  () => {
    cnpj.classList.toggle('blurred')
    ncnpje.classList.toggle('none')
    ncnpjce.classList.toggle('none')
})

ncnpjce.addEventListener('click',  () => {
    document.querySelector('#cnpj').classList.toggle('blurred')
    ncnpje.classList.toggle('none')
    ncnpjce.classList.toggle('none')
})


const scc1 = document.querySelector('#scc1')
const scce1 = document.querySelector('#scce1')
const n1 = document.querySelector('#n1')

scc1.addEventListener('click',  () => {
   n1.classList.toggle('blurred')
   scce1.classList.toggle('none')
   scc1.classList.toggle('none')
    
})


scce1.addEventListener('click',  () => {
   n1.classList.toggle('blurred')
   scce1.classList.toggle('none')
   scc1.classList.toggle('none')
    
})



const scc2 = document.querySelector('#scc2')
const scce2 = document.querySelector('#scce2')
const n2 = document.querySelector('#n2')

scc2.addEventListener('click',  () => {
    n2.classList.toggle('blurred')
    scce2.classList.toggle('none')
    scc2.classList.toggle('none')
    
})

scce2.addEventListener('click',  () => {
    n2.classList.toggle('blurred')
    scce2.classList.toggle('none')
    scc2.classList.toggle('none')
    
})

const scc3 = document.querySelector('#scc3')
const scce3 = document.querySelector('#scce3')
const n3 = document.querySelector('#n3')

scc3.addEventListener('click',  () => {
    n3.classList.toggle('blurred')
    scc3.classList.toggle('none')
    scce3.classList.toggle('none')
    
})

scce3.addEventListener('click',  () => {
    n3.classList.toggle('blurred')
    scc3.classList.toggle('none')
    scce3.classList.toggle('none')
    
})

const scc4 = document.querySelector('#scc4')
const scce4 = document.querySelector('#scce4')
const n4 = document.querySelector('#n4')

console.log(scce4);


scc4.addEventListener('click',  () => {
    n4.classList.toggle('blurred')
    scc4.classList.toggle('none')
    scce4.classList.toggle('none')
    
})

scce4.addEventListener('click',  () => {
    n4.classList.toggle('blurred')
    scc4.classList.toggle('none')
    scce4.classList.toggle('none')
    
})



const scc5 = document.querySelector('#scc5')
const scce5 = document.querySelector('#scce5')
const n5 = document.querySelector('#n5')

scc5.addEventListener('click',  () => {
    n5.classList.toggle('blurred')
    scc5.classList.toggle('none')
    scce5.classList.toggle('none')
})


scce5.addEventListener('click',  () => {
    n5.classList.toggle('blurred')
    scc5.classList.toggle('none')
    scce5.classList.toggle('none')
})

const scc6 = document.querySelector('#scc6')
const scce6 = document.querySelector('#scce6')
const n6 = document.querySelector('#n6')

scc6.addEventListener('click',  () => {
    n6.classList.toggle('blurred')
    scc6.classList.toggle('none')
    scce6.classList.toggle('none')
})

scce6.addEventListener('click',  () => {
    n6.classList.toggle('blurred')
    scc6.classList.toggle('none')
    scce6.classList.toggle('none')
})


const scc7 = document.querySelector('#scc7')
const scce7 = document.querySelector('#scce7')
const n7 = document.querySelector('#n7')

scc7.addEventListener('click',  () => {
    n7.classList.toggle('blurred')
    scc7.classList.toggle('none')
    scce7.classList.toggle('none')
    
})

scce7.addEventListener('click',  () => {
    n7.classList.toggle('blurred')
    scc7.classList.toggle('none')
    scce7.classList.toggle('none')
    
})

const scc8 = document.querySelector('#scc8')
const scce8 = document.querySelector('#scce8')
const n8 = document.querySelector('#n8')

scc8.addEventListener('click',  () => {
    n8.classList.toggle('blurred')
    scc8.classList.toggle('none')
    scce8.classList.toggle('none')
    
})

scce8.addEventListener('click',  () => {
    n8.classList.toggle('blurred')
    scc8.classList.toggle('none')
    scce8.classList.toggle('none')
    
})


const scc9 = document.querySelector('#scc9')
const scce9 = document.querySelector('#scce9')
const n9 = document.querySelector('#n9')

scc9.addEventListener('click',  () => {
    n9.classList.toggle('blurred')
    scc9.classList.toggle('none')
    scce9.classList.toggle('none')
    
})

scce9.addEventListener('click',  () => {
    n9.classList.toggle('blurred')
    scc9.classList.toggle('none')
    scce9.classList.toggle('none')
    
})



const scc10 = document.querySelector('#scc10')
const scce10 = document.querySelector('#scce10')
const n10 = document.querySelector('#n10')

scc10.addEventListener('click',  () => {
    n10.classList.toggle('blurred')
    scc10.classList.toggle('none')
    scce10.classList.toggle('none')
})

scce10.addEventListener('click',  () => {
    n10.classList.toggle('blurred')
    scc10.classList.toggle('none')
    scce10.classList.toggle('none')
})

 
const nall = document.querySelectorAll('.green')

const eyeall = document.querySelector('#eyeall')

const nall1 = [n1,n2,n3,n4,n5,n6,n7,n8,n9,n10]

console.log(eyeall);

const ne1 = document.querySelector('#ne1')
const nep1 = document.querySelector('#nep1')
const ne2 = document.querySelector('#ne2')
const nep2 = document.querySelector('#nep2')
const nep3 = document.querySelector('#nep3')
const ne3 = document.querySelector('#ne3')


const ntd1 = document.querySelector('#ntd1')
const ntd2 = document.querySelector('#ntd2')
const ntd3 = document.querySelector('#ntd3')
const ntd4 = document.querySelector('#ntd4')
const ntd5 = document.querySelector('#ntd5')
const ntd6 = document.querySelector('#ntd6')
const ntd7 = document.querySelector('#ntd7')
const ntd8 = document.querySelector('#ntd8')
const ntd9 = document.querySelector('#ntd9')
const ntd10 = document.querySelector('#ntd10')
const ntd11 = document.querySelector('#ntd11')
const ntd12 = document.querySelector('#ntd12')
const ntd13 = document.querySelector('#ntd13')

const ntd1_1 = document.querySelector('#ntd1_1')
const ntd2_1 = document.querySelector('#ntd2_1')
const ntd3_1 = document.querySelector('#ntd3_1')
const ntd4_1 = document.querySelector('#ntd4_1')
const ntd5_1 = document.querySelector('#ntd5_1')
const ntd6_1 = document.querySelector('#ntd6_1')
const ntd7_1 = document.querySelector('#ntd7_1')
const ntd8_1 = document.querySelector('#ntd8_1')
const ntd9_1 = document.querySelector('#ntd9_1')
const ntd10_1 = document.querySelector('#ntd10_1')
const ntd11_1 = document.querySelector('#ntd11_1')
const ntd12_1 = document.querySelector('#ntd12_1')
const ntd13_1 = document.querySelector('#ntd13_1')



const vsg1 = document.querySelector('#vsg1')
const vsg2 = document.querySelector('#vsg2')
const vsg3 = document.querySelector('#vsg3')
const vsg4 = document.querySelector('#vsg4')
const vsg5 = document.querySelector('#vsg5')



eyeall.addEventListener('click', () => {
    eyeall.classList.toggle('none')
    eyeallc.classList.toggle('none')
    n1.classList.toggle('blurred')
    n2.classList.toggle('blurred')
    n3.classList.toggle('blurred')
    n4.classList.toggle('blurred')
    n5.classList.toggle('blurred')
    n6.classList.toggle('blurred')
    n7.classList.toggle('blurred')
    n8.classList.toggle('blurred')
    n9.classList.toggle('blurred')
    n10.classList.toggle('blurred')
    ne1.classList.toggle('blurred')
    ne2.classList.toggle('blurred')
    ne3.classList.toggle('blurred')
    nep1.classList.toggle('blurred')
    nep2.classList.toggle('blurred')
    nep3.classList.toggle('blurred')
    scc1.classList.toggle('none')
    scce1.classList.toggle('none')
    scc2.classList.toggle('none')
    scce2.classList.toggle('none')
    scc3.classList.toggle('none')
    scce3.classList.toggle('none')
    scc4.classList.toggle('none')
    scce4.classList.toggle('none')
    scc5.classList.toggle('none')
    scce5.classList.toggle('none')
    scc6.classList.toggle('none')
    scce6.classList.toggle('none')
    scc7.classList.toggle('none')
    scce7.classList.toggle('none')
    scc8.classList.toggle('none')
    scce8.classList.toggle('none')
    scc9.classList.toggle('none')
    scce9.classList.toggle('none')
    scc10.classList.toggle('none')
    scce10.classList.toggle('none')

    ntd1.classList.toggle('blurred')
    ntd2.classList.toggle('blurred')
    ntd3.classList.toggle('blurred')
    ntd4.classList.toggle('blurred')
    ntd5.classList.toggle('blurred')
    ntd6.classList.toggle('blurred')
    ntd7.classList.toggle('blurred')
    ntd8.classList.toggle('blurred')
    ntd9.classList.toggle('blurred')
    ntd10.classList.toggle('blurred')
    ntd11.classList.toggle('blurred')
    ntd12.classList.toggle('blurred')
    ntd13.classList.toggle('blurred')
    ntd1_1.classList.toggle('blurred')
    ntd2_1.classList.toggle('blurred')
    ntd3_1.classList.toggle('blurred')
    ntd4_1.classList.toggle('blurred')
    ntd5_1.classList.toggle('blurred')
    ntd6_1.classList.toggle('blurred')
    ntd7_1.classList.toggle('blurred')
    ntd8_1.classList.toggle('blurred')
    ntd9_1.classList.toggle('blurred')
    ntd10_1.classList.toggle('blurred')
    ntd11_1.classList.toggle('blurred')
    ntd12_1.classList.toggle('blurred')
    ntd13_1.classList.toggle('blurred')

    vsg1.classList.toggle('blurred')
    vsg2.classList.toggle('blurred')
    vsg3.classList.toggle('blurred')
    vsg4.classList.toggle('blurred')
    vsg5.classList.toggle('blurred')
    

    
})

const eyeallc = document.querySelector('#eyeallc')

eyeallc.addEventListener('click', () => {
    eyeallc.classList.toggle('none')
    eyeall.classList.toggle('none')
    n1.classList.toggle('blurred')
    n2.classList.toggle('blurred')
    n3.classList.toggle('blurred')
    n4.classList.toggle('blurred')
    n5.classList.toggle('blurred')
    n6.classList.toggle('blurred')
    n7.classList.toggle('blurred')
    n8.classList.toggle('blurred')
    n9.classList.toggle('blurred')
    n10.classList.toggle('blurred')
    ne1.classList.toggle('blurred')
    ne2.classList.toggle('blurred')
    ne3.classList.toggle('blurred')
    nep1.classList.toggle('blurred')
    nep2.classList.toggle('blurred')
    nep3.classList.toggle('blurred')
    scc1.classList.toggle('none')
    scce1.classList.toggle('none')
    scc2.classList.toggle('none')
    scce2.classList.toggle('none')
    scc3.classList.toggle('none')
    scce3.classList.toggle('none')
    scc4.classList.toggle('none')
    scce4.classList.toggle('none')
    scc5.classList.toggle('none')
    scce5.classList.toggle('none')
    scc6.classList.toggle('none')
    scce6.classList.toggle('none')
    scc7.classList.toggle('none')
    scce7.classList.toggle('none')
    scc8.classList.toggle('none')
    scce8.classList.toggle('none')
    scc9.classList.toggle('none')
    scce9.classList.toggle('none')
    scc10.classList.toggle('none')
    scce10.classList.toggle('none')

    ntd1.classList.toggle('blurred')
    ntd2.classList.toggle('blurred')
    ntd3.classList.toggle('blurred')
    ntd4.classList.toggle('blurred')
    ntd5.classList.toggle('blurred')
    ntd6.classList.toggle('blurred')
    ntd7.classList.toggle('blurred')
    ntd8.classList.toggle('blurred')
    ntd9.classList.toggle('blurred')
    ntd10.classList.toggle('blurred')
    ntd11.classList.toggle('blurred')
    ntd12.classList.toggle('blurred')
    ntd13.classList.toggle('blurred')
    ntd1_1.classList.toggle('blurred')
    ntd2_1.classList.toggle('blurred')
    ntd3_1.classList.toggle('blurred')
    ntd4_1.classList.toggle('blurred')
    ntd5_1.classList.toggle('blurred')
    ntd6_1.classList.toggle('blurred')
    ntd7_1.classList.toggle('blurred')
    ntd8_1.classList.toggle('blurred')
    ntd9_1.classList.toggle('blurred')
    ntd10_1.classList.toggle('blurred')
    ntd11_1.classList.toggle('blurred')
    ntd12_1.classList.toggle('blurred')
    ntd13_1.classList.toggle('blurred')

    vsg1.classList.toggle('blurred')
    vsg2.classList.toggle('blurred')
    vsg3.classList.toggle('blurred')
    vsg4.classList.toggle('blurred')
    vsg5.classList.toggle('blurred')


})