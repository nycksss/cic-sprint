const cardData = [
    { icon: 'fa-eye', title: 'Visualizações por dia', value: '1' },
    { icon: 'fa-chart-line', title: 'Receita Operacional', value: 'R$ 26,47 mi' },
    { icon: 'fa-dollar-sign', title: 'Receita Líquida', value: 'R$ 26,12 mi' },
    { icon: 'fa-percentage', title: 'Margem de Contribuição', value: 'R$ 11,5 mi' },
    { icon: 'fa-coins', title: 'Custo de Operação', value: 'R$ 14,61 mi' },
    { icon: 'fa-chart-pie', title: 'Lucro Operacional', value: 'R$ 26,47 mi' },
    { icon: 'fa-users', title: 'Clientes Ativos', value: '1,234' },
    { icon: 'fa-shopping-cart', title: 'Vendas Realizadas', value: '5,678' },
    { icon: 'fa-box', title: 'Produtos Vendidos', value: '10,000' },
    { icon: 'fa-star', title: 'Satisfação do Cliente', value: '4.8/5' }
];