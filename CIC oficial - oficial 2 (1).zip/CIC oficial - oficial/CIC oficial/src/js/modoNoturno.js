// const dark= document.querySelector('#mododark')
// const lua= document.querySelector('#lua')
// const contrast= document.querySelector('#contrast')
// const sol= document.querySelector('#sol')
// const body = document.querySelector('body')

// const troca = document.querySelector('#troca')
// const dash = document.querySelector('#dash')
// const dash2 = document.querySelector('#dash2')
// const dash3 = document.querySelector('#dash3')

// console.log(troca);

// troca.addEventListener('click', () =>{
//     dash.classList.toggle('none')
//     dash2.classList.toggle('none')
//     dash3.classList.toggle('none')
    
// })

// lua.addEventListener('click', () =>{
//     lua.classList.toggle('none')
//     sol.classList.toggle('none')
//     body.classList.toggle('dark')
//     body.classList.remove('contrast')
// })

// sol.addEventListener('click', () =>{
//     lua.classList.toggle('none')
//     sol.classList.toggle('none')
//     body.classList.toggle('dark')
//     body.classList.remove('contrast')
// })


// contrast.addEventListener('click', () =>{
//     body.classList.toggle('contrast')
// })



const dark = document.querySelector('#mododark')
const lua = document.querySelector('#lua')
const contrast = document.querySelector('#contrast')
const sol = document.querySelector('#sol')
const body = document.querySelector('body')

const troca = document.querySelector('#troca')
const dash = document.querySelector('#dash')
const dash2 = document.querySelector('#dash2')
const dash3 = document.querySelector('#dash3')

const logo = document.querySelector('#logo')

const originalLogoSrc = './src/img/logo-cic-green.c649b6e3 2.png'
const contrastLogoSrc = './src/img/logo-cic-contrast.png'

let currentMode = 'normal' // Pode ser 'normal', 'dark', ou 'contrast'

function updateUI() {
    body.classList.remove('dark', 'contrast')
    lua.classList.remove('none')
    sol.classList.add('none')
    logo.setAttribute('src', originalLogoSrc)

    switch (currentMode) {
        case 'dark':
            body.classList.add('dark')
            lua.classList.add('none')
            sol.classList.remove('none')
            break
        case 'contrast':
            body.classList.add('contrast')
            logo.setAttribute('src', contrastLogoSrc)
            break
    }
}

function setMode(mode) {
    currentMode = mode
    updateUI()
}

troca.addEventListener('click', () => {
    dash.classList.toggle('none')
    dash2.classList.toggle('none')
    dash3.classList.toggle('none')
})

lua.addEventListener('click', () => setMode('dark'))
sol.addEventListener('click', () => setMode('normal'))

contrast.addEventListener('click', () => {
    setMode(currentMode === 'contrast' ? 'normal' : 'contrast')
})

// Inicialização
updateUI()